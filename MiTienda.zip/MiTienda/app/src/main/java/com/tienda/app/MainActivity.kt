package com.tienda.app

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class AppItem(
    val name: String,
    val desc: String,
    val version: String,
    val code: Long,
    val pkg: String,
    val url: String
)

class MainActivity : Activity() {

    // Cambiá TU_USUARIO/TU_REPO por los de tu GitHub
    private val catalogUrl =
        "https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/app/src/main/assets/apps.json"

    private val purple = 0xFF6750A4.toInt()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val items = mutableListOf<AppItem>()
    private val pending = mutableMapOf<Long, String>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            val file = pending.remove(id) ?: return
            install(File(getExternalFilesDir(null), file))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Boolean = false) = GradientDrawable().apply {
        if (stroke) {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), color)
        } else {
            setColor(color)
        }
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF6F2FA.toInt())
        }
        val bar = TextView(this).apply {
            text = "Mi Tienda"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        status = TextView(this).apply { setPadding(dp(20), dp(12), dp(20), 0) }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)

        ContextCompat.registerReceiver(
            this, receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
        load()
    }

    // Al volver de instalar/desinstalar, se refrescan los botones
    override fun onResume() {
        super.onResume()
        if (items.isNotEmpty()) render()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    private fun load() {
        status.text = "Cargando catálogo…"
        Thread {
            val json = try {
                val con = URL(catalogUrl).openConnection() as HttpURLConnection
                con.connectTimeout = 8000
                con.readTimeout = 8000
                con.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                // sin internet o URL aún no configurada: usa el catálogo incluido en la app
                assets.open("apps.json").bufferedReader().use { it.readText() }
            }
            runOnUiThread {
                try {
                    val arr = JSONArray(json)
                    items.clear()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        items.add(
                            AppItem(
                                o.getString("name"), o.optString("description"), o.optString("version"),
                                o.optLong("versionCode", 0), o.optString("package"), o.getString("url")
                            )
                        )
                    }
                    status.text = ""
                    render()
                } catch (e: Exception) {
                    status.text = "Error leyendo el catálogo"
                }
            }
        }.start()
    }

    private fun render() {
        list.removeAllViews()
        for (a in items) {
            list.addView(card(a), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(12) })
        }
    }

    private fun installedCode(pkg: String): Long? = try {
        PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(pkg, 0))
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    private fun btn(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(if (filled) Color.WHITE else purple)
        background = rounded(purple, 24, stroke = !filled)
        setOnClickListener { onClick() }
    }

    private fun card(a: AppItem): LinearLayout {
        val installed = if (a.pkg.isEmpty()) null else installedCode(a.pkg)
        val hasUpdate = installed != null && installed < a.code

        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 16)
            elevation = dp(2).toFloat()
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        c.addView(TextView(this).apply {
            text = a.name
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF1C1B1F.toInt())
        })
        c.addView(TextView(this).apply {
            text = a.desc
            setTextColor(0xFF49454F.toInt())
            setPadding(0, dp(4), 0, dp(4))
        })
        c.addView(TextView(this).apply {
            text = if (hasUpdate) "v${a.version} · Actualización disponible" else "v${a.version}"
            textSize = 12f
            setTextColor(if (hasUpdate) 0xFFB3261E.toInt() else 0xFF79747E.toInt())
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun lp() = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(8) }
        when {
            installed == null -> row.addView(btn("Instalar", true) { download(a) }, lp())
            hasUpdate -> {
                row.addView(btn("Actualizar", true) { download(a) }, lp())
                row.addView(btn("Desinstalar", false) { uninstall(a) }, lp())
            }
            else -> {
                row.addView(btn("Abrir", true) { open(a) }, lp())
                row.addView(btn("Desinstalar", false) { uninstall(a) }, lp())
            }
        }
        c.addView(row, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        return c
    }

    private fun open(a: AppItem) {
        val i = packageManager.getLaunchIntentForPackage(a.pkg)
        if (i != null) startActivity(i) else Toast.makeText(this, "No se puede abrir", Toast.LENGTH_SHORT).show()
    }

    private fun uninstall(a: AppItem) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
    }

    private fun download(a: AppItem) {
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Habilitá \"instalar apps desconocidas\" para Mi Tienda y volvé a tocar el botón", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val base = if (a.pkg.isNotEmpty()) a.pkg else a.name.replace(Regex("[^A-Za-z0-9]"), "_")
        val fileName = "$base.apk"
        File(getExternalFilesDir(null), fileName).delete()
        val req = DownloadManager.Request(Uri.parse(a.url))
            .setTitle(a.name)
            .setDestinationInExternalFilesDir(this, null, fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        pending[dm.enqueue(req)] = fileName
        Toast.makeText(this, "Descargando ${a.name}…", Toast.LENGTH_SHORT).show()
    }

    private fun install(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
